/**
 * @file course.h
 * @author Divye Goswami
 * @date 11-04-2022
 * @brief student database management, including course type definition 
 *        and student functions.
 *
 */

#include "student.h"
#include <stdbool.h>

/**
* _course type stores a course with fields name, code , total students and student.
*
*/
 
typedef struct _course 
{
  char name[100];/**< the course's  name */
  char code[10];/**< the course's  code */
  Student *students;/**< the pointer to the student of type Student */
  int total_students;/**< total number of students enrolled in the course */
} Course;
// creating function declaration for enrolling a student 
void enroll_student(Course *course, Student *student);
// creating function declaration for printing course data
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);
