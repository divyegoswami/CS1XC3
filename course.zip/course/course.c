/**
 * @file course.c
 * @author Divye Goswami
 * @date 11-04-2022
 * @brief Student database management, including  definitions 
 *        of student functions.
 *
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/** 
 * Enrolls a student into the course
 * 
 * @param course of type Course and student of type Student
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
  // Allocating a space for student in the course
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {// reallocating space for students if student in course > 1
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * Prints all information about the course like course name, course code, total students enrolled 
 *  in the course and lsit of all students enrolled in course.
 * 
 * @param Course a Course pointer represented as a type course.
 * @return nothing
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/** 
 * Gives the Student in the particular course who topped in that course
 * 
 * @param Course a Course pointer represented as a type course.
 * @return top_student of Type Student
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * Gives the Students passing in a course
 * 
 * @param Course a Course pointer represented as a type course and total number of passing students.
 * @return passing of type
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
  //CHecks if average marks of student is greater than 50
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {//Adds passed students to passing students
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}
