 /**
 * @file student.h
 * @author Divye Goswami
 * @date 11-04-2022
 * @brief student database management, including student type definition 
 *        and student functions.
 *
 */
 
 
/**
* _student type stores a student with fields first name, last name, id and grades.
*
*/
typedef struct _student 
{ 
  char first_name[50]; /**< the students's first name */
  char last_name[50]; /**< the students's last name */
  char id[11]; /**< the students's id */
  double *grades; /**< the pointer to students's grades */
  int num_grades; /**< the students's grades */
} Student;
// creating function declaration for adding grade 
void add_grade(Student *student, double grade);
// creating function declaration for returning student average
double average(Student *student);
// creating function declaraion for printing student data
void print_student(Student *student);
Student* generate_random_student(int grades); 
