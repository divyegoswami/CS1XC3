var searchData=
[
  ['student_0',['Student',['../student_8h.html#ac91ec92866bb82e1ee36c75280929c43',1,'student.h']]],
  ['student_20and_20course_20function_20demonstration_1',['Student and Course function demonstration',['../index.html',1,'']]],
  ['student_2ec_2',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh_3',['student.h',['../student_8h.html',1,'']]],
  ['students_4',['students',['../struct__course.html#a5cf448bc80f0f8c5f23402db23d41a00',1,'_course']]]
];
